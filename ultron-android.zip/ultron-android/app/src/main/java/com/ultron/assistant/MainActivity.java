package com.ultron.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_AUDIO = 7;

    private WebView web;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingLang = null;
    private int uttCounter = 0;
    private String currentUtt = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(0xFF02030A);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);

        web.addJavascriptInterface(new Bridge(), "UltronBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS) return;
                int r = tts.setLanguage(Locale.UK);
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        if (utteranceId.equals(currentUtt)) js("onSpeakStart()");
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        if (utteranceId.equals(currentUtt)) js("onSpeakEnd()");
                    }

                    @Override
                    public void onError(String utteranceId) {
                        if (utteranceId.equals(currentUtt)) js("onSpeakEnd()");
                    }

                    @Override
                    public void onRangeStart(String utteranceId, int start, int end, int frame) {
                        if (utteranceId.equals(currentUtt)) js("onWord(" + start + "," + end + ")");
                    }
                });
                ttsReady = true;
            }
        });
    }

    /** Run a call on window.UltronNative in the page. */
    private void js(final String call) {
        final String code = "window.UltronNative&&window.UltronNative." + call + ";";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    private void startListening(String lang) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("onError(12)");
            return;
        }
        if (recognizer != null) {
            try {
                recognizer.destroy();
            } catch (Exception ignored) { }
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(android.os.Bundle params) {
                js("onListening()");
            }

            @Override
            public void onBeginningOfSpeech() { }

            @Override
            public void onRmsChanged(float rmsdB) {
                float v = (rmsdB + 2f) / 12f;
                if (v < 0f) v = 0f;
                if (v > 1f) v = 1f;
                js("onRms(" + v + ")");
            }

            @Override
            public void onBufferReceived(byte[] buffer) { }

            @Override
            public void onEndOfSpeech() { }

            @Override
            public void onError(int error) {
                js("onError(" + error + ")");
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text = (r != null && !r.isEmpty()) ? r.get(0) : "";
                js("onFinal(" + JSONObject.quote(text) + ")");
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                ArrayList<String> r = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) js("onPartial(" + JSONObject.quote(r.get(0)) + ")");
            }

            @Override
            public void onEvent(int eventType, Bundle params) { }
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        recognizer.startListening(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_AUDIO) return;
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        String lang = pendingLang;
        pendingLang = null;
        if (ok && lang != null) startListening(lang);
        else js("onError(9)");
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (recognizer != null) recognizer.cancel();
            if (tts != null) tts.stop();
        } catch (Exception ignored) { }
        if (pendingLang == null) js("onAppPause()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (recognizer != null) recognizer.destroy();
            if (tts != null) {
                tts.stop();
                tts.shutdown();
            }
        } catch (Exception ignored) { }
        if (web != null) {
            web.removeJavascriptInterface("UltronBridge");
            web.destroy();
            web = null;
        }
    }

    /** Methods the page can call as window.UltronBridge.* */
    private class Bridge {

        @JavascriptInterface
        public void listen(final String lang) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startListening(lang);
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (recognizer != null) recognizer.cancel();
                    } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void speak(final String text, final String pitch, final String rate) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!ttsReady) {
                        js("onSpeakEnd()");
                        return;
                    }
                    float p = 0.75f, r = 0.95f;
                    try {
                        p = Float.parseFloat(pitch);
                        r = Float.parseFloat(rate);
                    } catch (Exception ignored) { }
                    String t = text;
                    int max = TextToSpeech.getMaxSpeechInputLength() - 10;
                    if (t.length() > max) t = t.substring(0, max);
                    tts.stop();
                    tts.setPitch(p);
                    tts.setSpeechRate(r);
                    currentUtt = "u" + (++uttCounter);
                    int res = tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, currentUtt);
                    if (res != TextToSpeech.SUCCESS) js("onSpeakEnd()");
                }
            });
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    currentUtt = "";
                    try {
                        if (tts != null) tts.stop();
                    } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public boolean openApp(String name) {
            PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN, null);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            String q = name.toLowerCase(Locale.ROOT).trim();
            if (q.isEmpty()) return false;
            ResolveInfo best = null;
            for (ResolveInfo ri : list) {
                String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
                if (label.equals(q)) {
                    best = ri;
                    break;
                }
                if (best == null && label.length() > 2 && (label.contains(q) || q.contains(label))) best = ri;
            }
            if (best == null) return false;
            final Intent launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
            if (launch == null) return false;
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(launch);
                    } catch (Exception ignored) { }
                }
            });
            return true;
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception ignored) { }
                }
            });
        }

        /** POST from native code so the page is not limited by browser CORS rules. */
        @JavascriptInterface
        public void http(final String id, final String url, final String headersJson, final String body) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    int status = 0;
                    String out = "";
                    try {
                        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                        c.setRequestMethod("POST");
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(90000);
                        c.setDoOutput(true);
                        JSONObject h = new JSONObject(headersJson);
                        Iterator<String> keys = h.keys();
                        while (keys.hasNext()) {
                            String k = keys.next();
                            c.setRequestProperty(k, h.getString(k));
                        }
                        OutputStream os = c.getOutputStream();
                        os.write(body.getBytes("UTF-8"));
                        os.close();
                        status = c.getResponseCode();
                        InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                        if (is != null) {
                            ByteArrayOutputStream bo = new ByteArrayOutputStream();
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                            is.close();
                            out = bo.toString("UTF-8");
                        }
                    } catch (Exception e) {
                        status = 0;
                        out = String.valueOf(e.getMessage());
                    }
                    js("onHttp(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(out) + ")");
                }
            }).start();
        }
    }
}
