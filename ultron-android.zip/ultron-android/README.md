# Ultron (Android voice assistant)

Voice only. Tap the orb and talk in Hindi, Hinglish or English. Ultron answers out loud in English,
searches the web, opens apps, creates images and remembers what you tell him.

## Get the APK (no coding)
1. Make a free GitHub account and create a new **public** repository.
2. Upload everything in this folder to it (keep the `.github/workflows/build-apk.yml` file in place).
3. Open the **Actions** tab, wait about 5 minutes for "Build Ultron APK" to turn green.
4. Open the repository's **Releases** page on your phone, download `Ultron.apk`, and install it
   (Android asks you to allow installs from your browser once).

## First run
Open the gear icon, tap the button to get a free Gemini key at aistudio.google.com/apikey, paste it, save.
Then tap the orb and speak. Allow the microphone when Android asks.
